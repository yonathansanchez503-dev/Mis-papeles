MIS PAPELES — COMPILACIÓN DESDE EL CELULAR CON GITHUB ACTIONS

Archivos:
1. MisPapelesAndroid-completo.zip — proyecto Android.
2. build-apk.yml — flujo que compila el APK automáticamente.

INSTRUCCIONES:
1. Crea una cuenta en GitHub si no tienes una.
2. Crea un repositorio NUEVO y marca Public.
3. Desde el navegador del celular, entra al repositorio.
4. Pulsa Add file > Upload files.
5. Sube estos DOS archivos:
   - MisPapelesAndroid-completo.zip
   - build-apk.yml
6. MUY IMPORTANTE: crea la carpeta .github/workflows y coloca
   build-apk.yml dentro de ella. Desde la interfaz web puedes abrir
   "Add file > Create new file" y escribir como nombre:
   .github/workflows/build-apk.yml
   Luego pega el contenido de build-apk.yml.
   El ZIP se sube normalmente a la raíz.
7. Ve a la pestaña Actions.
8. Selecciona "Crear APK de Mis Papeles".
9. Pulsa "Run workflow".
10. Espera a que termine.
11. Entra en la ejecución terminada.
12. En la sección Artifacts descarga "MisPapeles-APK".
13. Descomprime el archivo descargado y encontrarás app-debug.apk.
14. Abre el APK en tu Android e instala la aplicación.

El repositorio puede ser público para que GitHub Actions use sus
ejecutores estándar sin coste. GitHub indica que Actions es gratuito
para repositorios públicos y que las cuentas personales también tienen
una cuota mensual de Codespaces, aunque Codespaces no es necesario
para este procedimiento.
